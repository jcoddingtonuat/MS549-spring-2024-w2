#include <iostream>
#include <memory>

using namespace std;

int main()
{
	int n1 = 42;
	int* n1ptr = &n1;
	int* n2ptr;
	// NO  double* n3ptr = n1ptr;
	//n2ptr = n1ptr;
	
	cout << "n1ptr= " << n1ptr << endl;
	cout << "n1ptr dereferenced " << *n1ptr << endl;

	 
	int n2 = 53;
	n2ptr = n1ptr;
	//n2ptr = &n2;


	cout << "n2ptr= " << n2ptr << endl;
	cout << "n2ptr dereferenced " << *n2ptr << endl;


	int total = 0;
	total = *n2ptr + *n1ptr;
	cout << "total = " << total << endl;


	//smart pointers - unique

	unique_ptr<int> uniPtr = make_unique<int>(77);

	cout << "uniptr = " << uniPtr << endl;
	cout << "uniptr dereferenced = " << *uniPtr << endl;


		return 0;
}